function y = set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(116)=y(45);
y(117)=y(46);
y(118)=y(46);
y(119)=y(47);
y(120)=y(47);
y(121)=y(47);
y(122)=y(48);
y(123)=y(48);
y(124)=y(48);
y(125)=y(48);
y(126)=y(49);
y(127)=y(49);
y(128)=y(49);
y(129)=y(49);
y(130)=y(49);
y(131)=y(50);
y(132)=y(50);
y(133)=y(50);
y(134)=y(50);
y(135)=y(50);
y(136)=y(50);
y(137)=y(51);
y(138)=y(51);
y(139)=y(51);
y(140)=y(51);
y(141)=y(51);
y(142)=y(51);
y(143)=y(51);

function y = BGGsticky_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(110)=y(45);
y(111)=y(46);
y(112)=y(46);
y(113)=y(47);
y(114)=y(47);
y(115)=y(47);
y(116)=y(48);
y(117)=y(48);
y(118)=y(48);
y(119)=y(48);
y(120)=y(49);
y(121)=y(49);
y(122)=y(49);
y(123)=y(49);
y(124)=y(49);
y(125)=y(50);
y(126)=y(50);
y(127)=y(50);
y(128)=y(50);
y(129)=y(50);
y(130)=y(50);
y(131)=y(51);
y(132)=y(51);
y(133)=y(51);
y(134)=y(51);
y(135)=y(51);
y(136)=y(51);
y(137)=y(51);

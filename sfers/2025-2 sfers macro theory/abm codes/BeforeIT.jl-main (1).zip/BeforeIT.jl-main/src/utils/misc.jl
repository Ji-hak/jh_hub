fields(s) = Tuple(getfield(s, x) for x in fieldnames(typeof(s)))

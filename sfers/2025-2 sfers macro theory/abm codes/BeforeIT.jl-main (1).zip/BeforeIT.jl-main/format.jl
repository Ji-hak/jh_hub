import BeforeIT as Bit

using Runic

Bit.format_package()
